#!/bin/bash
# use: ./cifra.sh archivo_cifrado llave_privada

# Creamos variables
FILE=$1
PRIV_KEY=$2

# Desciframos el archivo y lo mandamos a un archivo
openssl rsautl -decrypt -inkey $PRIV_KEY -in $FILE > file.txt

# Mostramos el contenido
cat file.txt