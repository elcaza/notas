#!/bin/bash
# use: ./prueba.sh

# RSA se basa en el intercambio de llaves publicas y privadas para intercambiar mensajes
# En este ejemplo intercambiamos mensajes entre bob y alice

# Bob le enviará "Hola Alice" a Alice
# Alice va a descifrar su mensaje

#####################################################################

# Creamos las llaves de Bob
    # La publica se usa para que le envien mensajes (un candado)
    # La privada se usa para que el descifre el contenido de sus mensajes (su llave) solamente él puede leer los mensajes que le envien
echo "========================================="
echo "Creando llaves de Bob"
echo "========================================="
./crea_llaves.sh "bob"

# Creamos las llaves de Alice
    # La publica se usa para que le envien mensajes (un candado)
    # La privada se usa para que el descifre el contenido de sus mensajes (su llave) solamente él puede leer los mensajes que le envien
echo "========================================="
echo "Creando llaves de Alice"
echo "========================================="
./crea_llaves.sh "alice"

#####################################################################

# Vamos a mandar mensaje "Hola Alice"
# Insertamos el mensaje y lo ciframos con la llave pública de alice
echo "========================================="
echo "Cifrando mensaje para Alice"
echo "========================================="
./cifra.sh "Hola Alice" "alice_pub.pem"

#####################################################################

# Alice al recibir el mensaje lo lee con su llave privada

# Insertamos el mensaje y lo ciframos con la llave privada de alice
echo "========================================="
echo "Alice descifrando su mensaje secreto"
echo "========================================="

echo ""

echo "========================================="
./descifra.sh "file.bin" "alice_priv.pem"
echo "========================================="