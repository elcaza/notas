#!/bin/bash
# use: ./cifra.sh "string" public_key
# output: 
    # file.bin

# Creamos variables
MENSAJE=$1
PUB_KEY=$2

# Creamos un archivo temporal con el mensaje cifrado
echo $MENSAJE > file.txt 

# Ciframos con la llave pública de la persona a la que se le entregará el mensaje
openssl rsautl -encrypt -inkey $PUB_KEY -pubin -in file.txt -out file.bin 
# Borramos el archivo temporal
rm file.txt