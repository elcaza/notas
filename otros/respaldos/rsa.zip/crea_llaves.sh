#!/bin/bash
# use: ./crea_llaves.sh nombre_llave
# output: 
    # nombre_priv.pem
    # nombre_pub.pem

# Creamos variables
NOMBRE=$1
PRIVADA=$NOMBRE'_priv.pem'
PUBLICA=$NOMBRE'_pub.pem'

# Generamos la llave privada RSA
openssl genrsa -out $PRIVADA 1024 
openssl rsa -in $PRIVADA -text -noout 

# Generamos la llave publica RSA
openssl rsa -in $PRIVADA -pubout -out $PUBLICA
openssl rsa -in $PUBLICA -pubin -text -noout 